#!/bin/zsh
#WORKSPACE=../..
WORKSPACE=gen_client

GEN_CLIENT=${WORKSPACE}/Luban.Client.dll
CONF_ROOT=${WORKSPACE}/designer_configs


dotnet ${GEN_CLIENT} -h 127.0.0.1 -j cfg --\
 -d ${CONF_ROOT}/Defines/__root__.xml \
 --input_data_dir ${CONF_ROOT}/Datas \
 --output_code_dir ..\Assets\Script\DataTables \
 --output_data_dir ...\Assets\Res\DataTables \
 --gen_types code_cs_bin,data_bin \
 -s all 
