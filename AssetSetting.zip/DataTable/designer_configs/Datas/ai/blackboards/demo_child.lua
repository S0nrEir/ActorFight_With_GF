return {
	name = "demo",
	desc ="demo hahaha",
	parent_name = "demo_parent",
	keys =
	{
		{name="x1",desc="x1 haha", is_static=false, type="BOOL", type_class_name=""},
		{name="x2",desc="x2 haha", is_static=false, type="INT", type_class_name=""},
		{name="x3",desc="x3 haha", is_static=false, type="FLOAT", type_class_name=""},
		{name="x4",desc="x4 haha", is_static=false, type="STRING", type_class_name=""},
		{name="x5",desc="x5 haha", is_static=false, type="VECTOR", type_class_name=""},
		{name="x6",desc="x6 haha", is_static=false, type="ROTATOR", type_class_name=""},
		{name="x7",desc="x7 haha", is_static=false, type="NAME", type_class_name=""},
		{name="x8",desc="x8 haha", is_static=false, type="CLASS", type_class_name=""},
		{name="x9",desc="x9 haha", is_static=false, type="ENUM", type_class_name="ABC"},
		{name="x10",desc="x10 haha", is_static=false, type="OBJECT", type_class_name="OBJECT"},
	},
}