return {
	name = "attack_or_patrol",
	desc ="demo hahaha",
	parent_name = "",
	keys =
	{
		{name="OriginPosition",desc="", is_static=false, type="VECTOR", type_class_name=""},
		{name="TargetActor",desc="x2 haha", is_static=false, type="OBJECT", type_class_name=""},
		{name="AcceptableRadius",desc="x3 haha", is_static=false, type="FLOAT", type_class_name=""},
		{name="CurChooseSkillId",desc="x4 haha", is_static=false, type="INT", type_class_name=""},
	},
}